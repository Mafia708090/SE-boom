# MAO_TOOL


# First Tool Of Mao

# Coder Owner Of Mao2116

##thise is a education perpose Tool ,Not For Any Kind Of Illigal Activities
we are not promot any kind of illigal activities so be careful,,,
##


# Thank You For Stay With Us ,,,


We Work To Update Thise Tool We Give 2 Updates That's Are v.2.0 And v.2116/Finale Update.


Stay With Us And Keep Update Your Tool.


Commend FistTime Install:

$ apt update

$ apt upgrade

$ apt install git

$ apt install python 

$ git clone https://github.com/mao2116/MAO_TOOL/

$ cd MAO_TOOL

$ python3 maotool.py

# username: mao
# password: 2116



# Bangladeshi Coder



# Mao2116
